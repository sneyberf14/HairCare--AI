import React, { useEffect, useMemo, useState } from 'react';
import { supabase, configured } from './lib/supabase';
import { Camera, Sparkles, UserRound, Users, History, LogOut, ShieldCheck, ImagePlus, Heart, LockKeyhole, Menu, X, Leaf, Droplets, Scissors, ChevronRight } from 'lucide-react';

const family = [
  { name: 'Mi perfil', relation: 'Administrador', color: 'lavender', initials: 'YO' },
  { name: 'Mi novia', relation: 'Familiar', color: 'rose', initials: 'N' },
  { name: 'Mi mamá', relation: 'Familiar', color: 'peach', initials: 'M' },
  { name: 'Mi hermana', relation: 'Familiar', color: 'mint', initials: 'H' }
];

function App() {
  const [session, setSession] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState('login');
  const [active, setActive] = useState(0);
  const [photo, setPhoto] = useState('');
  const [file, setFile] = useState(null);
  const [analysis, setAnalysis] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [history, setHistory] = useState([]);
  const [mobileMenu, setMobileMenu] = useState(false);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  const adminEmail = import.meta.env.VITE_ADMIN_EMAIL || '';
  const isAdmin = Boolean(session?.user?.email && adminEmail && session.user.email.toLowerCase() === adminEmail.toLowerCase());

  async function authSubmit(e) {
    e.preventDefault(); setNotice('');
    if (!configured) { setNotice('Primero configura Supabase siguiendo INSTRUCCIONES.md. La vista de demostración está disponible sin cuenta.'); return; }
    const action = mode === 'login' ? supabase.auth.signInWithPassword({ email, password }) : supabase.auth.signUp({ email, password });
    const { error } = await action;
    setNotice(error ? error.message : (mode === 'login' ? 'Sesión iniciada.' : 'Revisa tu correo para confirmar la cuenta.'));
  }
  async function signOut() { if (supabase) await supabase.auth.signOut(); setSession(null); }
  function choosePhoto(e) {
    const selected = e.target.files?.[0];
    if (!selected) return;
    if (!selected.type.startsWith('image/')) { setNotice('Selecciona una imagen.'); return; }
    if (selected.size > 8 * 1024 * 1024) { setNotice('La foto debe pesar menos de 8 MB.'); return; }
    setFile(selected); setPhoto(URL.createObjectURL(selected)); setAnalysis(''); setNotice('');
  }
  async function analyze() {
    if (!file) { setNotice('Primero toma o selecciona una fotografía.'); return; }
    setBusy(true); setNotice(''); setAnalysis('');
    try {
      const api = import.meta.env.VITE_API_URL || 'http://localhost:3001';
      const form = new FormData(); form.append('photo', file);
      form.append('hairProfile', family[active].name);
      const response = await fetch(`${api}/api/analyze`, { method: 'POST', body: form });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudo analizar la foto.');
      setAnalysis(result.analysis);
      setHistory(old => [{ date: new Date().toLocaleString('es-CO'), profile: family[active].name, result: result.analysis }, ...old].slice(0, 10));
    } catch (err) {
      setNotice(err.message || 'No se pudo conectar con el servicio de análisis.');
    } finally { setBusy(false); }
  }

  if (configured && !session) return <div className="auth-shell"><div className="auth-card">
    <div className="brand-mark"><Sparkles size={23}/></div><p className="eyebrow">TU RUTINA, TU CABELLO</p><h1>HairCare <span>AI</span></h1>
    <p className="muted">Cuidado capilar inteligente para toda la familia.</p>
    <form onSubmit={authSubmit}><label>Correo electrónico</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="tu@correo.com"/><label>Contraseña</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength="6" placeholder="Mínimo 6 caracteres"/><button className="primary full" type="submit">{mode==='login'?'Iniciar sesión':'Crear cuenta'}</button></form>
    <button className="link-button" onClick={()=>setMode(mode==='login'?'signup':'login')}>{mode==='login'?'¿No tienes cuenta? Regístrate':'Ya tengo cuenta'}</button>
    {notice && <p className="notice">{notice}</p>}
  </div></div>;

  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu?'show':''}`}>
      <div className="brand"><div className="brand-mark"><Sparkles size={22}/></div><div><b>HairCare <span>AI</span></b><small>BEAUTY, MEET INTELLIGENCE</small></div><button className="close-menu" onClick={()=>setMobileMenu(false)}><X/></button></div>
      <div className="side-label">MENÚ PRINCIPAL</div>
      <button className="nav-item selected"><Sparkles size={18}/> Mi espacio</button>
      <button className="nav-item" onClick={()=>document.getElementById('analysis')?.scrollIntoView({behavior:'smooth'})}><Camera size={18}/> Análisis capilar</button>
      <button className="nav-item" onClick={()=>document.getElementById('history')?.scrollIntoView({behavior:'smooth'})}><History size={18}/> Mi historial</button>
      <div className="side-label family-label">PERFILES FAMILIARES</div>
      {family.map((p,i)=><button key={p.name} className={`profile-nav ${active===i?'active':''}`} onClick={()=>{setActive(i);setPhoto('');setFile(null);setAnalysis('');setMobileMenu(false)}}><span className={`avatar ${p.color}`}>{p.initials}</span><span>{p.name}<small>{p.relation}</small></span>{active===i&&<span className="dot"/>}</button>)}
      <div className="sidebar-bottom"><div className="privacy-note"><LockKeyhole size={16}/><span>Los perfiles deben mantener sus fotos y resultados privados.</span></div>{session ? <button className="nav-item" onClick={signOut}><LogOut size={18}/> Cerrar sesión</button> : <span className="demo-pill">Vista de demostración</span>}</div>
    </aside>
    <main className="main">
      <header className="topbar"><button className="menu-button" onClick={()=>setMobileMenu(true)}><Menu/></button><div><span className="eyebrow">ESPACIO PERSONAL</span><h2>Hola, {family[active].name.replace('Mi ','')} <span>✦</span></h2></div><div className="top-actions">{isAdmin&&<span className="admin-pill"><ShieldCheck size={15}/> Administrador</span>}<div className="top-avatar">{family[active].initials}</div></div></header>
      {!configured&&<div className="setup-banner"><b>Modo de demostración.</b> La interfaz ya está lista; para activar cuentas privadas e IA real, configura las claves siguiendo INSTRUCCIONES.md.</div>}
      <section className="hero">
        <div className="hero-copy"><span className="hero-tag"><Sparkles size={14}/> CUIDADO CAPILAR INTELIGENTE</span><h1>Tu cabello tiene<br/>una historia. <i>Descúbrela.</i></h1><p>Conoce mejor tu cabello y crea una rutina que se adapte a ti, con ayuda de inteligencia artificial.</p><button className="hero-button" onClick={()=>document.getElementById('analysis').scrollIntoView({behavior:'smooth'})}>Analizar mi cabello <ChevronRight size={18}/></button></div>
        <div className="hero-art"><div className="orb orb-one"></div><div className="orb orb-two"></div><div className="hair-illustration"><div className="hair-head"></div><div className="hair-flow"></div><div className="hair-neck"></div></div><div className="floating-card"><Sparkles size={16}/><span><b>Tu rutina, a tu medida</b><small>Un cuidado más consciente</small></span></div></div>
      </section>
      <section className="section-head" id="analysis"><div><span className="eyebrow">EMPECEMOS POR CONOCERLO</span><h2>Analiza tu cabello</h2><p>Usa una foto clara, con buena luz y sin filtros.</p></div><span className="step-count">01 <i>/ 03</i></span></section>
      <section className="analysis-grid">
        <div className="upload-card">
          <div className="upload-heading"><div className="icon-tile"><Camera/></div><div><h3>Tu fotografía</h3><p>Frente o parte superior del cabello</p></div></div>
          <label className="upload-zone">{photo?<img src={photo} alt="Vista previa de tu cabello"/>:<><div className="upload-icon"><ImagePlus size={27}/></div><b>Sube una fotografía</b><span>JPG o PNG · Máximo 8 MB</span><em>Elegir desde galería</em></>}<input type="file" accept="image/*" capture="environment" onChange={choosePhoto}/></label>
          <button className="primary full" onClick={analyze} disabled={busy||!file}>{busy?'Analizando...':'<Analizar con IA />'.replace(/[<>/]/g,'')} <Sparkles size={17}/></button>
          <p className="privacy-caption"><LockKeyhole size={13}/> Usa una foto propia y evita incluir rostros de otras personas.</p>
        </div>
        <div className="info-card"><div className="icon-tile pale"><Heart/></div><span className="eyebrow">ANTES DE COMENZAR</span><h3>Una foto puede ser el primer paso hacia una mejor rutina.</h3><p>La IA puede orientar sobre características visibles, pero una foto no permite diagnosticar enfermedades del cuero cabelludo ni determinar por sí sola la causa de la caída.</p><div className="tip-row"><span><Droplets size={16}/></span><p><b>Buena iluminación</b><small>Busca luz natural y evita sombras fuertes.</small></p></div><div className="tip-row"><span><Scissors size={16}/></span><p><b>Cabello visible</b><small>Evita gorros, filtros y productos que lo cubran.</small></p></div></div>
      </section>
      {notice&&<div className="notice">{notice}</div>}
      {analysis&&<section className="result-card"><div className="result-title"><div className="icon-tile"><Sparkles/></div><div><span className="eyebrow">RESULTADO DE TU ANÁLISIS</span><h2>Lo que observamos</h2></div></div><p className="analysis-text">{analysis}</p><p className="disclaimer">Orientación cosmética basada en la imagen, no es un diagnóstico médico.</p></section>}
      <section className="section-head history-head" id="history"><div><span className="eyebrow">TU CAMINO CAPILAR</span><h2>Historial reciente</h2><p>Los análisis de esta sesión aparecen aquí.</p></div><History size={23}/></section>
      {history.length===0?<div className="empty-history"><div className="empty-icon"><History size={22}/></div><b>Tu historia empieza aquí</b><p>Cuando realices tu primer análisis, podrás verlo en esta sección.</p></div>:history.map((h,i)=><article className="history-item" key={i}><div className="history-icon"><Leaf/></div><div><b>{h.profile}</b><small>{h.date}</small><p>{h.result.slice(0,180)}...</p></div></article>)}
      <footer>HAIRCARE AI <span>•</span> Cuidado capilar con intención.</footer>
    </main>
  </div>;
}
export default App;
import express from 'express';
import cors from 'cors';
import multer from 'multer';
import dotenv from 'dotenv';

dotenv.config();
const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });
app.use(cors({ origin: true }));
app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'HairCare AI' }));

app.post('/api/analyze', upload.single('photo'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Falta la fotografía.' });
    if (!process.env.GEMINI_API_KEY) return res.status(503).json({ error: 'Falta configurar GEMINI_API_KEY en el servidor. Consulta INSTRUCCIONES.md.' });
    const mimeType = req.file.mimetype;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(mimeType)) {
      return res.status(400).json({ error: 'Formato no compatible. Usa JPG, PNG o WEBP.' });
    }
    const base64 = req.file.buffer.toString('base64');
    const prompt = `Eres un asistente de cuidado cosmético capilar. Observa únicamente características visibles en esta fotografía. Responde en español sencillo y amable. Describe con cautela textura y aspectos visibles como frizz, brillo o resequedad aparente SOLO si son apreciables. No diagnostiques alopecia, dermatitis, infecciones, enfermedades ni deficiencias. No afirmes causas médicas ni prometas resultados. Da 3 consejos generales y seguros de cuidado y aclara las limitaciones de una fotografía. Si no se ve suficiente cabello, dilo claramente. Perfil seleccionado: ${req.body.hairProfile || 'persona'}.`;
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${process.env.GEMINI_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }, { inline_data: { mime_type: mimeType, data: base64 } }] }], generationConfig: { temperature: 0.3, maxOutputTokens: 700 } })
    });
    const data = await response.json();
    if (!response.ok) return res.status(502).json({ error: data.error?.message || 'El servicio de IA no respondió correctamente.' });
    const analysis = data.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('\n').trim();
    if (!analysis) return res.status(502).json({ error: 'La IA no devolvió un análisis.' });
    res.json({ analysis });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error interno al analizar la fotografía.' });
  }
});
const port = process.env.PORT || 3001;
app.listen(port, () => console.log(`HairCare AI API disponible en puerto ${port}`));